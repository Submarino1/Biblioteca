
function login() 
{
 let pass = document.getElementById("contrasena").value;
 if (pass == "a"){
window.location = "Menu.html";
 }
 else(alert("Contraseña equivocada"))
 
}
function guardarDatos(){
    let left = (screen.width - 600)/2;
let top = (screen.height - 700)/2;
    window.open("AggLibro.html","Document", `widht=600, height=500, top=${top}, left=${left}`)

    fetch('Menu.html')
    .then(response => response.text())
    .then(html => {

    var parser = new DOMParser();
    var doc = parser.parseFromString(html, 'text/html');

    var tabla = document.getElementById("tabla").getElementsByTagName('tbody')[0];

    var nuevaFila = tabla.insertRow(tabla.rows.lenght);
    
    let celda1 = fila.insertCell(0);
    let celda2 = fila.insertCell(1);
    let celda3 = fila.insertCell(2);
    let celda4 = fila.insertCell(3);
    let celda5 = fila.insertCell(4);
    let celda6 = fila.insertCell(5);
    celda1.innerHTML = libro.titulo;
    celda2.innerHTML = libro.autor;
    celda3.innerHTML = libro.fechaPub;
    celda4.innerHTML = libro.editorial;
    celda5.innerHTML = libro.cantidad;
    celda6.innerHTML = libro.opciones;
    

    window.location.href = "Menu.html";
    }).catch(error => {
        console.error('Error al cargar el archivo:', error);
    }); 
    recargarConHistorial(); 
    window.close();
}
function recargarConHistorial(){
    history.go(0);
  
}

   