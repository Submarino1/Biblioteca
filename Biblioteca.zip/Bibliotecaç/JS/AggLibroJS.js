
let botonAceptar = document.getElementById("Aceptar");
let botonCancelar = document.getElementById("Cancelar");
function cerrarVentana(){
    window.close("/HTML/AddCliente.html","Document")
}
function capturarLibro() {
    let titulo = document.getElementById("titulo").value.trim();
    let fechaPub = document.getElementById("fechaPub").value.trim();
    let cantidad = document.getElementById("cantidad").value.trim();
    let autor = document.getElementById("autor").value.trim();
    let editorial = document.getElementById("editorial").value.trim();

    if (!titulo || !fechaPub || !cantidad || !autor || !editorial) {
        alert("Por favor, completa todos los campos.");
        return;
    }

    alert(
        `Datos ingresados correctamente:\n\n` +
        `Título: ${titulo}\n` +
        `Fecha de Publicación: ${fechaPub}\n` +
        `Cantidad en Stock: ${cantidad}\n` +
        `Autor: ${autor}\n` +
        `Editorial: ${editorial}`
    );

    document.querySelector(".FormularioLibroNuevo").reset();
}




/*
    fetch('Menu.html')
    .then(response => response.text())
    .then(html => {

    var parser = new DOMParser();
    var doc = parser.parseFromString(html, 'text/html');

    var tabla = document.getElementById("tabla").getElementsByTagName('tbody')[0];

    var nuevaFila = tabla.insertRow(tabla.rows.lenght);
    
    let celda1 = fila.insertCell(0);
    let celda2 = fila.insertCell(1);
    let celda3 = fila.insertCell(2);
    let celda4 = fila.insertCell(3);
    let celda5 = fila.insertCell(4);
    let celda6 = fila.insertCell(5);
    celda1.innerHTML = libro.titulo;
    celda2.innerHTML = libro.autor;
    celda3.innerHTML = libro.fechaPub;
    celda4.innerHTML = libro.editorial;
    celda5.innerHTML = libro.cantidad;
    celda6.innerHTML = libro.opciones;
    

    window.location.href = "Menu.html";
    }).catch(error => {
        console.error('Error al cargar el archivo:', error);
    }); 
    recargarConHistorial(); 
    window.close();
    function recargarConHistorial(){
    history.go(0);
  
}

*/


   