function formularioLibroNuevo(){
    let left = (screen.width - 600)/2;
    let top = (screen.height - 700)/2;
        window.open("/HTML/AggLibro.html","Document", `width=600, height=600, top=${top}, left=${left}`)
    
}
function opcionesClientes(){
    let left = (screen.width - 600)/2;
    let top = (screen.height - 700)/2;
        window.open("/HTML/opcionesClientes.html","Document", `width=600, height=600, top=${top}, left=${left}`)
    
}

function cerrarVentana(){
    window.close("/HTML/AddCliente.html","Document")
}