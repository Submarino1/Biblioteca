function addCliente(){
let left = (screen.width - 600)/2;
let top = (screen.height - 700)/2;
    window.open("/HTML/AddCliente.html","Document", `width=600, height=900, top=${top}, left=${left}`)
}
function cerrarVentana(){
        window.close("/HTML/AddCliente.html","Document")
    }
function capturarCliente() {
    let nombre = document.getElementById("nombre").value.trim();
    let direccion = document.getElementById("direccion").value.trim();
    let telefono = document.getElementById("telefono").value.trim();
    let email = document.getElementById("email").value.trim();

    if (!nombre || !direccion || !telefono || !email ) {
        alert("Por favor, completa todos los campos.");
        return;
    }

    alert(
        `Datos ingresados correctamente:\n\n` +
        `Nombre: ${nombre}\n` +
        `Direccion: ${direccion}\n` +
        `Telefono: ${telefono}\n` +
        `Correo Electronico: ${email}`
    );

    document.querySelector(".FormularioClienteNuevo").reset();
}
