function login(){
    let pass = document.getElementById("contrasena").value;
    if(pass == "" ){
        alert("Debe acceder la contraseña que se le fue asignada")
    } else if (pass == "RDAB"){
        window.location = "/HTML/Menu.html";
    } else(alert("Contraseña equivocada"))

}
